async def mute_user(*args,**kwargs): pass
