async def send_log(*args,**kwargs): pass
