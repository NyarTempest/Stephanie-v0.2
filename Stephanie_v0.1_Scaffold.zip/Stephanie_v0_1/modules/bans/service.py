async def ban_user(*args,**kwargs): pass
