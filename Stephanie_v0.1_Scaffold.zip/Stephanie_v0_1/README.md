# Stephanie v0.1

Telegram group management bot.

## Features
- Ban/Mute/Warn
- Unban/Unmute/Unwarn
- Log channels
- Punishment history
- Settings UI
- PostgreSQL + Redis

## Run
1. Copy .env.example to .env
2. pip install -r requirements.txt
3. python run.py
