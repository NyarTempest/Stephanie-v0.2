# fields:
# id,chat_id,user_id,moderator_id,
# type,reason,duration,
# issued_at,expires_at,
# removed,removed_by,removed_reason,removed_at
