from aiogram import Bot,Dispatcher
from config.settings import BOT_TOKEN
import asyncio
bot=Bot(BOT_TOKEN)
dp=Dispatcher()
async def main():
    print('Stephanie v0.1 started')
    await dp.start_polling(bot)
